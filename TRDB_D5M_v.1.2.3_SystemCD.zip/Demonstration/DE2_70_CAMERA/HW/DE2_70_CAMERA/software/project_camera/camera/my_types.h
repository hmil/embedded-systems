#ifndef MY_TYPES_H_
#define MY_TYPES_H_

typedef int bool;
#define TRUE    1
#define FALSE   0



#endif /*MY_TYPES_H_*/
