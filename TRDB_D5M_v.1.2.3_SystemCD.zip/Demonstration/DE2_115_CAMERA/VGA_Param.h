//NOTE:you can mask the below macro definition to select the 800*600 solution, unmask it for 640*480 solution
//`define VGA_640x480p60 1



